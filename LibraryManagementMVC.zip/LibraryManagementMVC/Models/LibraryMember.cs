namespace LibraryManagementMVC.Models;

public class LibraryMember
{
    public int MemberId { get; set; }

    [Required]
    public string MemberName { get; set; } = "";

    [Required]
    public string Department { get; set; } = "";

    [Required]
    [EmailAddress]
    public string Email { get; set; } = "";

    [Required]
    public int BookId { get; set; }

    [Required]
    public DateTime IssueDate { get; set; }

    [Required]
    public DateTime DueDate { get; set; }

    public DateTime? ReturnDate { get; set; }
}