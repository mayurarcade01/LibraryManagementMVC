namespace LibraryManagementMVC.Models;

public class Book
{
    public int BookId { get; set; }

    [Required]
    public string Title { get; set; } = "";

    [Required]
    public string Author { get; set; } = "";

    [Required]
    public string Category { get; set; } = "";

    public decimal Price { get; set; }

    public int AvailableCopies { get; set; }
}