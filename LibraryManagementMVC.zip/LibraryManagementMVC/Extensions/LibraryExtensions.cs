namespace LibraryManagementMVC.Extensions;

public static class LibraryExtensions
{
    public static string GetDueStatus(this LibraryMember member)
    {
        if (member.ReturnDate.HasValue)
            return "Returned";

        if (member.DueDate < DateTime.Today)
            return "Overdue";

        if ((member.DueDate - DateTime.Today).TotalDays <= 3)
            return "Due Soon";

        return "Issued";
    }

    public static decimal CalculateFine(this LibraryMember member)
    {
        if (!member.ReturnDate.HasValue)
            return 0;

        if (member.ReturnDate.Value.Date <= member.DueDate.Date)
            return 0;

        int overdueDays =
            (member.ReturnDate.Value.Date - member.DueDate.Date).Days;

        return overdueDays * 10;
    }
}