using LibraryManagementMVC.Extensions;
using Microsoft.AspNetCore.Mvc;

namespace LibraryManagementMVC.Controllers;

public class LibraryController : Controller
{
    private static List<Book> Books = new()
    {
        new Book
        {
            BookId = 1,
            Title = "C# Programming",
            Author = "Joseph Albahari",
            Category = "Programming",
            Price = 500,
            AvailableCopies = 5
        },
        new Book
        {
            BookId = 2,
            Title = "ASP.NET Core",
            Author = "Andrew Lock",
            Category = "Web Development",
            Price = 650,
            AvailableCopies = 3
        },
        new Book
        {
            BookId = 3,
            Title = "Database Systems",
            Author = "Raghu Ramakrishnan",
            Category = "Database",
            Price = 700,
            AvailableCopies = 4
        }
    };

    private static List<LibraryMember> IssuedBooks = new()
    {
        new LibraryMember
        {
            MemberId = 1,
            MemberName = "Rahul Patil",
            Department = "Computer",
            Email = "rahul@example.com",
            BookId = 1,
            IssueDate = DateTime.Today.AddDays(-5),
            DueDate = DateTime.Today.AddDays(2),
            ReturnDate = null
        }
    };

    public IActionResult Index()
    {
        ViewBag.Books = Books;
        return View(IssuedBooks);
    }

    [HttpGet]
    public IActionResult IssueBook()
    {
        return View();
    }

    [HttpPost]
    [HttpPost]
public IActionResult IssueBook(LibraryMember member)
{
    if (!ModelState.IsValid)
        return View(member);

    member.MemberId = IssuedBooks.Count + 1;
    member.ReturnDate = null;

    IssuedBooks.Add(member);

    return RedirectToAction("Index");
}

    public IActionResult BookDetails(int id)
    {
        var member = IssuedBooks.FirstOrDefault(x => x.MemberId == id);

        if (member == null)
            return NotFound();

        ViewBag.Book = Books.FirstOrDefault(x => x.BookId == member.BookId);

        return View(member);
    }

    [HttpPost]
public IActionResult ReturnBook(int id)
{
    var member = IssuedBooks.FirstOrDefault(x => x.MemberId == id);

    if (member == null)
        return NotFound();

    if (!member.ReturnDate.HasValue)
    {
        member.ReturnDate = DateTime.Today;
    }

    TempData["SuccessMessage"] = "Book returned successfully.";

    return RedirectToAction("Index");
}

    public IActionResult About()
    {
        return View();
    }
}