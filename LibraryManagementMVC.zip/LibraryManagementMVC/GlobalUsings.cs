global using System.ComponentModel.DataAnnotations;
global using System.Collections.Generic;
global using LibraryManagementMVC.Models;